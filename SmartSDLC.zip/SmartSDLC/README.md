# SmartSDLC

AI-powered toolkit to enhance the Software Development Lifecycle with code reviews, documentation, and bug detection.