from ibm_watsonx_ai.foundation_models import ChatModel

print("ChatModel imported successfully")
